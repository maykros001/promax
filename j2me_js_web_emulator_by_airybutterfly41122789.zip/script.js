document.addEventListener('DOMContentLoaded', () => {
  const jarFile = document.getElementById('jar-file');
  const loadButton = document.getElementById('load-button');
  const emulatorCanvas = document.getElementById('emulator');
  const emulatorContainer = document.getElementById('emulator-container');
  const fullscreenButton = document.getElementById('fullscreen-button');
  const gameList = document.getElementById('game-list');

  let emulator;
  let savedGames = [];

  // Load saved games from localStorage
  if (localStorage.getItem('savedGames')) {
    savedGames = JSON.parse(localStorage.getItem('savedGames'));
    populateGameList();
  }

  loadButton.addEventListener('click', () => {
    const file = jarFile.files[0];
    if (!file) {
      alert('Please select a JAR file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const jarData = new Uint8Array(event.target.result);
      const gameName = file.name.replace('.jar', '');

      if (emulator) {
        emulator.destroy();
      }

      emulator = new J2ME(emulatorCanvas, {
        jar: jarData,
      });

      emulator.start();

      emulatorCanvas.width = emulator.getWidth();
      emulatorCanvas.height = emulator.getHeight();

      emulatorContainer.style.width = emulatorCanvas.width + "px";
      emulatorContainer.style.height = emulatorCanvas.height + "px";

      // Save the game
      saveGame(gameName, jarData);
    };

    reader.readAsArrayBuffer(file);
  });

  fullscreenButton.addEventListener('click', () => {
    if (emulatorContainer.requestFullscreen) {
      emulatorContainer.requestFullscreen();
    } else if (emulatorContainer.mozRequestFullScreen) { /* Firefox */
      emulatorContainer.mozRequestFullScreen();
    } else if (emulatorContainer.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
      emulatorContainer.webkitRequestFullscreen();
    } else if (emulatorContainer.msRequestFullscreen) { /* IE/Edge */
      emulatorContainer.msRequestFullscreen();
    }
  });

  function saveGame(name, data) {
    const game = {
      name: name,
      data: Array.from(data), // Store as array of numbers
    };

    savedGames.push(game);
    localStorage.setItem('savedGames', JSON.stringify(savedGames));
    populateGameList();
  }

  function loadGame(game) {
    const jarData = new Uint8Array(game.data);

    if (emulator) {
      emulator.destroy();
    }

    emulator = new J2ME(emulatorCanvas, {
      jar: jarData,
    });

    emulator.start();

    emulatorCanvas.width = emulator.getWidth();
    emulatorCanvas.height = emulator.getHeight();

    emulatorContainer.style.width = emulatorCanvas.width + "px";
    emulatorContainer.style.height = emulatorCanvas.height + "px";
  }

  function populateGameList() {
    gameList.innerHTML = ''; // Clear the list

    savedGames.forEach((game, index) => {
      const listItem = document.createElement('li');
      listItem.textContent = game.name;
      listItem.addEventListener('click', () => {
        loadGame(game);
      });

      const deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.addEventListener('click', (event) => {
        event.stopPropagation(); // Prevent loading the game
        deleteGame(index);
      });

      listItem.appendChild(deleteButton);
      gameList.appendChild(listItem);
    });
  }

  function deleteGame(index) {
    savedGames.splice(index, 1);
    localStorage.setItem('savedGames', JSON.stringify(savedGames));
    populateGameList();
  }
});